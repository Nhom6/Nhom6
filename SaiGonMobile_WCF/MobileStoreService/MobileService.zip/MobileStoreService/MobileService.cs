﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using MobileStoreService;

namespace MobileStoreService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MobileService" in both code and config file together.
    public class MobileService : IMobileService
    {
        MobileDBContext db = new MobileDBContext();
        //PRODUCT
        public List<Product> GetAll() 
        {
            return db.Products.ToList();
        }
        public Product GetByID(string id)
        {
            Product product = db.Products.Find(id);
            return product;
        }
        public void AddProduct(Product product)
        {
            db.Products.Add(product);
            db.SaveChanges();
        }
        public void UpdateProduct(Product product)
        {
            db.Entry(product).State = System.Data.EntityState.Modified;
            db.SaveChanges();
        }
        public void DeleteProduct(string id)
        {
            Product product = db.Products.Find(id);
            db.Products.Remove(product);
            db.SaveChanges();
        }
        //CATEGORY
        public List<Category> GetAllCategory()
        {
            return db.Categories.ToList();
        }
        public List<Category> GetAllCategory1()
        {
            return db.Categories.ToList();
        }
        public Category GetCategoryByID(int id)
        {
            Category category = db.Categories.Find(id);
            return category;
        }
        public void AddCategory(Category category)
        {
            db.Categories.Add(category);
            db.SaveChanges();
        }
        public void UpdateCategory(Category category)
        {
            db.Entry(category).State = System.Data.EntityState.Modified;
            db.SaveChanges();
        }
        public void DeleteCategory(int id)
        {
            Category category = db.Categories.Find(id);
            db.Categories.Remove(category);
            db.SaveChanges();
        }
        //Product By Category
        public List<Product> GetProductByCategory(int id)
        {
            var productbycategory = (from product in db.Products
                                    where product.CategoryID == id
                                    select product).ToList();
            return productbycategory;
        }
        //Detail in Product
        public List<Product> GetDetailById(string id)
        {
            var detailinproduct = (from product in db.Products
                                  where product.ID == id
                                  select product).ToList();
            return detailinproduct;
        }
        //LogIn WINFORM
        public bool Check_Login(string account, string password)
        {
            try{
            
                var acc = (from account1 in db.Accounts
                      where account1.ID.Equals(account)
                      select new 
                      {
                          account = account1.ID ,
                          password =account1.Password 
                      }).Single();
                if (password.Equals(password))
                { 
                    return true; 
                }
                return false;

            }
            catch{
                return false;
            }
        }
        //LogIn MVC
        public Account LogIn(string account, string password)
        {
            var acc = (from account1 in db.Accounts
                       where account1.ID == account && account1.Password == password
                       select account1).SingleOrDefault();
            return acc;
        }
        
            
    }
}
