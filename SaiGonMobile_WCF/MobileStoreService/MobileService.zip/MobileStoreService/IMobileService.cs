﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace MobileStoreService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IMobileService" in both code and config file together.
    [ServiceContract]
    public interface IMobileService
    {
        //Interface Product
        [OperationContract]
        List<Product> GetAll();
        [OperationContract]
        Product GetByID(string id);
        [OperationContract]
        void AddProduct(Product product);
        [OperationContract]
        void UpdateProduct(Product product);
        [OperationContract]
        void DeleteProduct(string id);
        //Interface Category
        [OperationContract]
        List<Category> GetAllCategory();
        [OperationContract]
        List<Category> GetAllCategory1();
        [OperationContract]
        Category GetCategoryByID(int id);
        [OperationContract]
        void AddCategory(Category category);
        [OperationContract]
        void UpdateCategory(Category category);
        [OperationContract]
        void DeleteCategory(int id);
        //Interface Product by Category
        [OperationContract]
        List<Product> GetProductByCategory(int id);
        //Interface Detail in Product
        [OperationContract]
        List<Product> GetDetailById(string id);
        //Interface LogIn WINFORM
        [OperationContract]
        bool Check_Login(string account, string password);
        //Interface Login MVC
        [OperationContract]
        Account LogIn(string account, string password);
    }
}
